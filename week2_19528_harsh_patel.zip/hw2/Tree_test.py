import Tree
import sys, getopt

def usage():
   print ('Usage: Triangle.py -h')
   print ('Usage: Triangle.py -h  -s -m ')
   print ('Usage: Triangle.py --hour=<hour> --sec=<sec> --minute=<minute>')

def main(argv):
   hour = ''
   sec = ''
   minute = ''
   try:
      opts, args = getopt.getopt(argv,"h:s:m:",["hour=", "sec=", "minute="])
   except getopt.GetoptError:
      usage()
      sys.exit(2)

   for opt, arg in opts:
      if opt == '-h':
         usage()
         sys.exit()
      elif opt in ("-h", "--hour"):
         hour = arg
      elif opt in ("-s", "--sec"):
         sec = arg
      elif opt in ("-m", "--minute"):
         minute = arg

   try:
      t1 = Tree.Tree(int(hour),int(sec),int(minute))
      print(t1.toString())
      t1.setMinute(75)
      print("after change minute to 75:"+ t1.toString())

   except Tree.ErrorHour as obj:
      print("Error", obj.getCode(),": The hour", obj.getNum(), "is not right.")
   except Tree.ErrorSec as obj:
      print("Error", obj.getCode(),": The sec", obj.getNum(), "is not right.")
   except Tree.ErrorMinute as obj:
      print("Error", obj.getCode(),": The minute", obj.getNum(), "is not right.")
   else:
      print("No exception.")
   finally:
      print("End")

if __name__ == '__main__':
   main(sys.argv[1:])
