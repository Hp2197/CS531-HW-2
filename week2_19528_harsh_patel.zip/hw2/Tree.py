
class ErrorCode(Exception):
   """The base class of erros"""
   #__code=0
    
   # constructor
   def __init__(self, n):
        self.__code = n
   def getCode(self):
        return self.__code

class ErrorHour(ErrorCode):
   """Raised when the input value is Negative"""
   #__num=0

   # constructor
   def __init__(self, n):
        ErrorCode.__init__(self, 1)
        self.__num = n
   def getNum(self):
        return self.__num

class ErrorMinute(ErrorCode):
   """Raised when the input value is more than 130"""
   #__num=0

   # constructor
   def __init__(self, n):
      ErrorCode.__init__(self, 2)
      self.__num = n
   def getNum(self):
      return self.__num

class ErrorSec(ErrorCode):
   """Raised when the input value is more than 130"""
   #__num=0

   # constructor
   def __init__(self, n):
      ErrorCode.__init__(self, 3)
      self.__num = n
   def getNum(self):
      return self.__num


class Tree:
    ############################
    # Helping function
    ############################
    def __trace(self, s):
        print(s)

    ############################
    # Manager function
    ############################
    # Including a default contrutctor
    def __init__(self, h,s,m):
        if h < 24:
           raise ErrorHour(h)
        elif (s < 0) + (s > 60):
           raise ErrorSec(s)
        elif (m < 0) + (m > 60):
           raise ErrorMinute(m)
        self.__hour = h
        self.__sec = s
        self.__minute = m
    def __del__(self):
        pass

    ############################
    # Access function
    ############################
    def getYear(self):
        return self.__hour
    def setYear(self, h):
        self.__hour = h
    def getDay(self):
        return self.__sec
    def setDay(self, s):
        self.__sec = s
    def getMonth(self):
        return self.__minute
    def setMonth(self, m):
        self.__minute = m
    #def isCentennial(self):
        #return self.__age %100 == 0

    ############################
    # Implementor function
    ############################
    def toString(self):
        return ("hour=" + str(self.__hour)+ "\n" \
        + "minute=" + str(self.__minute)+ "\n" \
        +"sec=" + str(self.__sec))
    def reset(self):
        hour = 0
        minute = 0
        sec = 0
